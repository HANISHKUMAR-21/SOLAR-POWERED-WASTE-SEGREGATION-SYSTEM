package com.example.solarwaste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SolarwasteApplication {

	public static void main(String[] args) {
		SpringApplication.run(SolarwasteApplication.class, args);
	}

}
