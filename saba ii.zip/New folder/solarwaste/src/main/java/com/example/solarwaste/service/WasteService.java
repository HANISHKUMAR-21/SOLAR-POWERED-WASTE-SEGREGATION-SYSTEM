
package com.example.solarwaste.service;

import com.example.solarwaste.entity.WasteRecord;
import com.example.solarwaste.repository.WasteRepository;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class WasteService {

    private final WasteRepository wasteRepository;

    public WasteService(WasteRepository wasteRepository) {
        this.wasteRepository = wasteRepository;
    }

    public WasteRecord saveWaste(WasteRecord record) {
        return wasteRepository.save(record);
    }

    public List<WasteRecord> getAllWaste() {
        return wasteRepository.findAll();
    }

    public void deleteWaste(Long id) {
        wasteRepository.deleteById(id);
    }
}
