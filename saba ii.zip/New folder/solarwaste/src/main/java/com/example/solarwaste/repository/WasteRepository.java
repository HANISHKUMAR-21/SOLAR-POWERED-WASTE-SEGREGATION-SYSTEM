
package com.example.solarwaste.repository;

import com.example.solarwaste.entity.WasteRecord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WasteRepository extends JpaRepository<WasteRecord, Long> {

}
