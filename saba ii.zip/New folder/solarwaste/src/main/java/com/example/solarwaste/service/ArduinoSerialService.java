
package com.example.solarwaste.service;

import com.example.solarwaste.entity.WasteRecord;
import com.fazecast.jSerialComm.SerialPort;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;

@Component
public class ArduinoSerialService implements ApplicationRunner {

    private final WasteService wasteService;

    public ArduinoSerialService(WasteService wasteService) {
        this.wasteService = wasteService;
    }

    @Override
    public void run(ApplicationArguments args) {

        SerialPort port = SerialPort.getCommPort("COM5");
        port.setBaudRate(9600);
        port.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING, 0, 0);

        if (!port.openPort()) {
            System.out.println("Arduino port could not be opened.");
            return;
        }

        System.out.println("Arduino connected to Java!");

        Thread receiver = new Thread(() -> {

            int metalValue = 1;
            int moistureValue = 1023;
            String lastCategory = "";

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(port.getInputStream()))) {

                String line;

                while ((line = reader.readLine()) != null) {
                    System.out.println("Received: " + line);

                    if (line.startsWith("Metal Sensor:")) {
                        metalValue = Integer.parseInt(
                            line.split(":")[1].trim());
                    }

                    if (line.startsWith("Moisture Sensor:")) {
                        moistureValue = Integer.parseInt(
                            line.split(":")[1].trim());

                        String category = "";

                        if (metalValue == 0) {
                            category = "Metal Waste";
                        } else if (moistureValue < 1005) {
                            category = "Wet Waste";
                        }

                        if (!category.equals(lastCategory)) {

                            if (!category.isEmpty()) {
                                WasteRecord record = new WasteRecord();
                                record.setCategory(category);
                                record.setWeight(0.0);

                                wasteService.saveWaste(record);

                                System.out.println(
                                    "Saved: " + category);
                            }

                            lastCategory = category;
                        }
                    }
                }

            } catch (Exception e) {
                System.out.println("Serial error: " + e.getMessage());
            }

        });

        receiver.setDaemon(true);
        receiver.start();
    }
}
